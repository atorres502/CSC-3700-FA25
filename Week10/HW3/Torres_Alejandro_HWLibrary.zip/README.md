Name: Alejandro Torres
Description: This program displays the books checked out in a library. It provides a summary that gives
information about which books are available, checked out, and exist. It gives information about the patrons
and which books they checked out. There's also a summary about the patrons, including information about, the
total patrons, the number of books checked out, and the average books checked out per patron.

Working Routes: /books, /books/summary, /patrons, /patrons/:id, /patrons/summary

![Screenshot 2025-10-30 at 12.40.29 PM.png](../../../../../Desktop/Screenshot%202025-10-30%20at%2012.40.29%E2%80%AFPM.png)

![Screenshot 2025-10-30 at 12.40.39 PM.png](../../../../../Desktop/Screenshot%202025-10-30%20at%2012.40.39%E2%80%AFPM.png)