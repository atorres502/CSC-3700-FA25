import React from 'react';

function About(props) {
    return (
        <div> <h2> This program demonstrates some of the react functionality learned in class</h2></div>
    );
}

export default About;